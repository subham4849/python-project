// FitnessManager.cpp
// Function definitions for the FitnessManager class.

#include "FitnessManager.h"

#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

// ---------------------------------------------------------------
// Small helper functions used only inside this file
// ---------------------------------------------------------------
namespace {

// Removes spaces (and \r from Windows line endings) at both ends
string trim(const string& text) {
    size_t start = 0;
    while (start < text.size() && isspace(static_cast<unsigned char>(text[start]))) {
        start++;
    }
    size_t end = text.size();
    while (end > start && isspace(static_cast<unsigned char>(text[end - 1]))) {
        end--;
    }
    return text.substr(start, end - start);
}

string toLower(string text) {
    for (size_t i = 0; i < text.size(); i++) {
        text[i] = static_cast<char>(tolower(static_cast<unsigned char>(text[i])));
    }
    return text;
}

// Converts text to int. Returns false if the text is not a whole number.
bool parseInt(const string& text, int& value) {
    try {
        size_t used = 0;
        value = stoi(text, &used);
        return used == text.size();
    } catch (...) {
        return false;
    }
}

// Converts text to double. Returns false if the text is not a number.
bool parseDouble(const string& text, double& value) {
    try {
        size_t used = 0;
        value = stod(text, &used);
        return used == text.size();
    } catch (...) {
        return false;
    }
}

}  // end of unnamed namespace

// ---------------------------------------------------------------
// Constructor and destructor
// ---------------------------------------------------------------
FitnessManager::FitnessManager(const string& fileName) : fileName(fileName) {
}

// The vector holds pointers, so every object must be deleted here.
FitnessManager::~FitnessManager() {
    for (size_t i = 0; i < workouts.size(); i++) {
        delete workouts[i];
    }
}

// ---------------------------------------------------------------
// Private helper functions
// ---------------------------------------------------------------

// Creates the right type of object for the activity name.
// Returns nullptr if the activity is not recognised.
Workout* FitnessManager::createWorkout(int id, const string& date,
                                       const string& activity, double distance,
                                       int duration, int calories) const {
    string type = toLower(trim(activity));

    if (type == "running") {
        return new RunningWorkout(id, date, distance, duration, calories);
    }
    if (type == "walking") {
        return new WalkingWorkout(id, date, distance, duration, calories);
    }
    if (type == "cycling") {
        return new Workout(id, date, "Cycling", distance, duration, calories);
    }
    return nullptr;
}

// Returns the position of the workout with this ID, or -1 if none
int FitnessManager::findIndexById(int id) const {
    for (size_t i = 0; i < workouts.size(); i++) {
        if (workouts[i]->getId() == id) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

// Next ID = largest existing ID + 1
int FitnessManager::getNextId() const {
    int maxId = 0;
    for (size_t i = 0; i < workouts.size(); i++) {
        if (workouts[i]->getId() > maxId) {
            maxId = workouts[i]->getId();
        }
    }
    return maxId + 1;
}

// ---------------------------------------------------------------
// File handling
// ---------------------------------------------------------------

// Reads every line of the file: id,date,activity,distance,duration,calories
void FitnessManager::loadFromFile() {
    ifstream file(fileName.c_str());
    if (!file) {
        cout << "No saved file found. Starting with an empty list.\n";
        return;
    }

    string line;
    int lineNumber = 0;

    while (getline(file, line)) {
        lineNumber++;
        line = trim(line);
        if (line.empty()) {
            continue;
        }

        // Split the line at the commas
        stringstream ss(line);
        string idText, date, activity, distText, durText, calText;
        getline(ss, idText, ',');
        getline(ss, date, ',');
        getline(ss, activity, ',');
        getline(ss, distText, ',');
        getline(ss, durText, ',');
        getline(ss, calText);

        int id = 0, duration = 0, calories = 0;
        double distance = 0.0;

        bool valid = parseInt(trim(idText), id) &&
                     parseDouble(trim(distText), distance) &&
                     parseInt(trim(durText), duration) &&
                     parseInt(trim(calText), calories) &&
                     id > 0 && distance > 0 && duration > 0 && calories >= 0 &&
                     findIndexById(id) == -1;           // no duplicate IDs

        Workout* workout = nullptr;
        if (valid) {
            workout = createWorkout(id, trim(date), activity,
                                    distance, duration, calories);
        }

        if (workout == nullptr) {
            cout << "Warning: line " << lineNumber
                 << " of " << fileName << " is invalid and was skipped.\n";
        } else {
            workouts.push_back(workout);
        }
    }

    cout << workouts.size() << " workout record(s) loaded from "
         << fileName << ".\n";
}

// Writes all records to the file (the old content is replaced)
bool FitnessManager::saveToFile() const {
    ofstream file(fileName.c_str());
    if (!file) {
        return false;
    }
    for (size_t i = 0; i < workouts.size(); i++) {
        file << workouts[i]->toFileString() << "\n";
    }
    return file.good();
}

// ---------------------------------------------------------------
// Main operations
// ---------------------------------------------------------------

void FitnessManager::addWorkout(const string& date, const string& activity,
                                double distance, int duration, int calories) {
    int id = getNextId();
    Workout* workout = createWorkout(id, date, activity,
                                     distance, duration, calories);
    if (workout == nullptr) {
        cout << "Unknown activity type. Workout not added.\n";
        return;
    }

    workouts.push_back(workout);
    cout << "\nWorkout added successfully with ID " << id << ".\n";

    if (!saveToFile()) {
        cout << "Warning: could not save to " << fileName << ".\n";
    }
}

void FitnessManager::viewAllWorkouts() const {
    if (workouts.empty()) {
        cout << "\nNo workout records found.\n";
        return;
    }

    cout << "\n===== All Workouts (" << workouts.size() << ") =====\n";
    for (size_t i = 0; i < workouts.size(); i++) {
        workouts[i]->display();         // polymorphism: correct version runs
        cout << "  ------------------------------\n";
    }
}

bool FitnessManager::searchWorkout(int id) const {
    int index = findIndexById(id);
    if (index == -1) {
        cout << "\nNo workout found with ID " << id << ".\n";
        return false;
    }

    cout << "\n===== Workout Found =====\n";
    workouts[index]->display();
    return true;
}

bool FitnessManager::deleteWorkout(int id) {
    int index = findIndexById(id);
    if (index == -1) {
        return false;
    }

    delete workouts[index];                         // free the memory
    workouts.erase(workouts.begin() + index);       // remove the pointer

    if (!saveToFile()) {
        cout << "Warning: could not save to " << fileName << ".\n";
    }
    return true;
}

double FitnessManager::calculateTotalDistance() const {
    double total = 0.0;
    for (size_t i = 0; i < workouts.size(); i++) {
        total += workouts[i]->getDistance();
    }
    return total;
}

void FitnessManager::displaySummary() const {
    if (workouts.empty()) {
        cout << "\nNo workout records found. Add a workout first.\n";
        return;
    }

    int runCount = 0, walkCount = 0, cycleCount = 0;
    double runDistance = 0.0;
    int runMinutes = 0;
    int totalMinutes = 0, totalCalories = 0;

    for (size_t i = 0; i < workouts.size(); i++) {
        string type = workouts[i]->getActivity();

        if (type == "Running") {
            runCount++;
            runDistance += workouts[i]->getDistance();
            runMinutes += workouts[i]->getDuration();
        } else if (type == "Walking") {
            walkCount++;
        } else if (type == "Cycling") {
            cycleCount++;
        }

        totalMinutes += workouts[i]->getDuration();
        totalCalories += workouts[i]->getCalories();
    }

    double totalDistance = calculateTotalDistance();
    double count = static_cast<double>(workouts.size());

    cout << "\n===== Fitness Summary =====\n";
    cout << fixed << setprecision(2);
    cout << "  Total workouts      : " << workouts.size() << "\n";
    cout << "  Running             : " << runCount << "\n";
    cout << "  Walking             : " << walkCount << "\n";
    cout << "  Cycling             : " << cycleCount << "\n";
    cout << "  Total distance      : " << totalDistance << " km\n";
    cout << "  Average distance    : " << totalDistance / count << " km\n";
    cout << "  Total duration      : " << totalMinutes << " min\n";
    cout << "  Average duration    : " << totalMinutes / count << " min\n";
    cout << "  Total calories      : " << totalCalories << " kcal\n";

    if (runDistance > 0) {
        double averagePace = runMinutes / runDistance;
        cout << "  Average running pace: "
             << Workout::formatPace(averagePace) << "\n";
    } else {
        cout << "  Average running pace: no running workouts yet\n";
    }
}
