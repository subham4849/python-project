// FitnessManager.h
// The FitnessManager class stores all workouts and performs the
// operations: add, view, search, delete, total distance, summary,
// and saving/loading the text file.

#ifndef FITNESSMANAGER_H
#define FITNESSMANAGER_H

#include <string>
#include <vector>

#include "Workout.h"

class FitnessManager {
private:
    // Pointers to the base class: each pointer can hold a Workout,
    // RunningWorkout or WalkingWorkout object (polymorphism).
    std::vector<Workout*> workouts;
    std::string fileName;

    // Private helper functions
    Workout* createWorkout(int id, const std::string& date,
                           const std::string& activity, double distance,
                           int duration, int calories) const;
    int findIndexById(int id) const;
    int getNextId() const;

public:
    explicit FitnessManager(const std::string& fileName);
    ~FitnessManager();

    // Copying is switched off, because two managers must not
    // delete the same workout objects.
    FitnessManager(const FitnessManager&) = delete;
    FitnessManager& operator=(const FitnessManager&) = delete;

    // File handling
    void loadFromFile();
    bool saveToFile() const;

    // Main operations
    void addWorkout(const std::string& date, const std::string& activity,
                    double distance, int duration, int calories);
    void viewAllWorkouts() const;
    bool searchWorkout(int id) const;        // returns true if found
    bool deleteWorkout(int id);              // returns true if deleted
    double calculateTotalDistance() const;
    void displaySummary() const;
};

#endif
