# Fitness Management System (C++ OOP)

A console-based C++ project that stores workout records in a text file and
manages them using Object-Oriented Programming.

## Abstract

The Fitness Management System is a console application written in C++ that
helps a user record and review workouts. Each workout has an ID, date,
activity type (running, walking or cycling), distance in kilometres, duration
in minutes and calories burned. The program shows how Object-Oriented
Programming is used in a real task: a base class `Workout` holds the common
data, the classes `RunningWorkout` and `WalkingWorkout` inherit from it, and a
`FitnessManager` class controls all records. Records are saved in a text file
(`workouts.txt`) with `fstream`, so they remain available after the program
closes. The program validates every input, calculates running pace and total
distance, and shows a fitness summary.

## Objectives

1. To apply classes, objects, encapsulation, inheritance and polymorphism in C++.
2. To store and read records permanently using file handling (`fstream`).
3. To add, display, search and delete workout records.
4. To calculate running pace (minutes per km) and total distance.
5. To show a fitness summary of all workouts.
6. To handle invalid input without crashing the program.
7. To keep the code simple, modular and easy to explain in a practical examination.

## Features

1. Add a new workout record (ID is generated automatically).
2. Display all workout records.
3. Calculate running pace from distance and duration.
4. Calculate total distance covered.
5. Search a workout by ID.
6. Delete a workout record (with confirmation).
7. Display a fitness summary (counts, totals, averages, average running pace).
8. Save records in `workouts.txt` automatically after every change.
9. Input validation for menu choices, dates (YYYY-MM-DD), numbers and activity type.

## Project Structure

```
fitness_management_system/
├── main.cpp              menu and input checking
├── Workout.h             Workout, RunningWorkout, WalkingWorkout (declarations)
├── Workout.cpp           their function definitions
├── FitnessManager.h      FitnessManager (declaration)
├── FitnessManager.cpp    its function definitions, file handling
├── workouts.txt          saved records (sample data included)
└── README.md
```

## Data File Format (`workouts.txt`)

One workout per line, fields separated by commas:

```
id,date,activity,distance,duration,calories
1,2026-10-01,Running,3.00,24,250
```

## OOP Concepts Used

| Concept | Where it is used |
| --- | --- |
| Classes and objects | `Workout`, `RunningWorkout`, `WalkingWorkout`, `FitnessManager`; every record is an object |
| Encapsulation | All data members are `private`; access is through public getters and setters |
| Inheritance | `RunningWorkout` and `WalkingWorkout` derive from `Workout` |
| Polymorphism | Virtual `display()`; a `Workout*` pointer runs the correct version at run time |
| Constructors | Default and parameterized constructors; derived constructors call the base constructor |
| Destructor | Virtual destructor in `Workout`; `FitnessManager` deletes its objects |
| File handling | `ifstream` loads records, `ofstream` saves them |

## Compile and Run (VS Code on Windows)

1. Install a C++ compiler (MinGW-w64 through MSYS2) and add its `bin` folder to PATH.
2. Install VS Code and the **C/C++** extension (Microsoft).
3. Open the folder `fitness_management_system` in VS Code (**File > Open Folder**).
4. Open the terminal (**Ctrl + `**) and check the compiler: `g++ --version`
5. Compile:

   ```
   g++ -std=c++17 -Wall main.cpp Workout.cpp FitnessManager.cpp -o fitness.exe
   ```

6. Run (from inside the project folder, so `workouts.txt` is found):

   ```
   .\fitness.exe
   ```

## Conclusion

The project meets all its objectives. It stores workouts as objects, uses
inheritance and virtual functions to show running, walking and cycling records
in different ways, and saves every change to a file so that data is never lost.
Separating the code into `Workout`, `FitnessManager` and `main` keeps it easy
to read, test and extend, for example with new activity types or an edit option.
