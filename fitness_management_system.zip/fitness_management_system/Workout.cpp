// Workout.cpp
// Function definitions for Workout, RunningWorkout and WalkingWorkout.

#include "Workout.h"

#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

// ================= Workout (base class) =================

// Default constructor: sets safe starting values
Workout::Workout()
    : id(0), date(""), activity(""), distance(0.0), duration(0), calories(0) {
}

// Parameterized constructor
Workout::Workout(int id, const string& date, const string& activity,
                 double distance, int duration, int calories)
    : id(id), date(date), activity(activity),
      distance(distance), duration(duration), calories(calories) {
}

Workout::~Workout() {
}

// ---------- Getters ----------
int Workout::getId() const { return id; }
string Workout::getDate() const { return date; }
string Workout::getActivity() const { return activity; }
double Workout::getDistance() const { return distance; }
int Workout::getDuration() const { return duration; }
int Workout::getCalories() const { return calories; }

// ---------- Setters (reject invalid values) ----------
void Workout::setDate(const string& newDate) {
    if (!newDate.empty()) {
        date = newDate;
    }
}

void Workout::setDistance(double newDistance) {
    if (newDistance > 0) {
        distance = newDistance;
    }
}

void Workout::setDuration(int newDuration) {
    if (newDuration > 0) {
        duration = newDuration;
    }
}

void Workout::setCalories(int newCalories) {
    if (newCalories >= 0) {
        calories = newCalories;
    }
}

// ---------- Calculations ----------

// Pace = duration (minutes) / distance (km)
double Workout::calculatePace() const {
    if (distance <= 0) {
        return 0.0;                     // avoids division by zero
    }
    return duration / distance;
}

// Speed = distance (km) / time (hours)
double Workout::calculateSpeed() const {
    if (duration <= 0) {
        return 0.0;
    }
    return distance / (duration / 60.0);
}

string Workout::formatPace(double pace) {
    int minutes = static_cast<int>(pace);
    int seconds = static_cast<int>((pace - minutes) * 60 + 0.5);
    if (seconds == 60) {                // rounding: 6:60 becomes 7:00
        minutes++;
        seconds = 0;
    }
    ostringstream out;
    out << minutes << ":" << setw(2) << setfill('0') << seconds << " min/km";
    return out.str();
}

// ---------- Display ----------

// Prints the details every workout has
void Workout::printCommon() const {
    cout << "  Workout ID : " << id << "\n";
    cout << "  Date       : " << date << "\n";
    cout << "  Activity   : " << activity << "\n";
    cout << fixed << setprecision(2);
    cout << "  Distance   : " << distance << " km\n";
    cout << "  Duration   : " << duration << " min\n";
    cout << "  Calories   : " << calories << " kcal\n";
}

// Base version: used for Cycling, shows average speed
void Workout::display() const {
    printCommon();
    cout << fixed << setprecision(2);
    cout << "  Avg Speed  : " << calculateSpeed() << " km/h\n";
}

string Workout::toFileString() const {
    ostringstream out;
    out << id << "," << date << "," << activity << ","
        << fixed << setprecision(2) << distance << ","
        << duration << "," << calories;
    return out.str();
}

// ================= RunningWorkout =================

// The constructor calls the base-class constructor and fixes
// the activity name to "Running".
RunningWorkout::RunningWorkout(int id, const string& date,
                               double distance, int duration, int calories)
    : Workout(id, date, "Running", distance, duration, calories) {
}

// Running shows the common details plus the running pace
void RunningWorkout::display() const {
    printCommon();
    cout << "  Run Pace   : " << formatPace(calculatePace()) << "\n";
}

// ================= WalkingWorkout =================

WalkingWorkout::WalkingWorkout(int id, const string& date,
                               double distance, int duration, int calories)
    : Workout(id, date, "Walking", distance, duration, calories) {
}

// Walking shows the common details plus speed and pace
void WalkingWorkout::display() const {
    printCommon();
    cout << fixed << setprecision(2);
    cout << "  Avg Speed  : " << calculateSpeed() << " km/h\n";
    cout << "  Walk Pace  : " << formatPace(calculatePace()) << "\n";
}
