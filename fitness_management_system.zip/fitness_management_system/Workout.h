// Workout.h
// Declares the base class Workout and the derived classes
// RunningWorkout and WalkingWorkout.

#ifndef WORKOUT_H
#define WORKOUT_H

#include <string>

// ---------------------------------------------------------------
// Base class: one workout record.
// A plain Workout object is used for Cycling.
// ---------------------------------------------------------------
class Workout {
private:                                // Encapsulation: data is private
    int id;
    std::string date;                   // format YYYY-MM-DD
    std::string activity;               // Running, Walking or Cycling
    double distance;                    // kilometres
    int duration;                       // minutes
    int calories;                       // kcal

protected:
    // Helper used by display() of this class and the derived classes.
    void printCommon() const;

public:
    // Constructors
    Workout();
    Workout(int id, const std::string& date, const std::string& activity,
            double distance, int duration, int calories);

    // Virtual destructor: needed when deleting a derived object
    // through a base-class pointer.
    virtual ~Workout();

    // Getters (public functions to read private data)
    int getId() const;
    std::string getDate() const;
    std::string getActivity() const;
    double getDistance() const;
    int getDuration() const;
    int getCalories() const;

    // Setters (public functions to change private data safely)
    void setDate(const std::string& newDate);
    void setDistance(double newDistance);
    void setDuration(int newDuration);
    void setCalories(int newCalories);

    // Calculations
    double calculatePace() const;       // minutes per km
    double calculateSpeed() const;      // km per hour

    // Polymorphism: derived classes change how details are displayed.
    virtual void display() const;

    // One CSV line: id,date,activity,distance,duration,calories
    std::string toFileString() const;

    // Turns 6.75 into "6:45 min/km"
    static std::string formatPace(double pace);
};

// ---------------------------------------------------------------
// Derived class: running workout (also shows running pace)
// ---------------------------------------------------------------
class RunningWorkout : public Workout {
public:
    RunningWorkout(int id, const std::string& date,
                   double distance, int duration, int calories);
    void display() const override;
};

// ---------------------------------------------------------------
// Derived class: walking workout (also shows speed and pace)
// ---------------------------------------------------------------
class WalkingWorkout : public Workout {
public:
    WalkingWorkout(int id, const std::string& date,
                   double distance, int duration, int calories);
    void display() const override;
};

#endif
