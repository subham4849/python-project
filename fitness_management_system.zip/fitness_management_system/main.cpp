// main.cpp
// Console menu for the Fitness Management System.
// This file only handles the user interface and input checking.
// All the real work is done by the FitnessManager class.

#include <cctype>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

#include "FitnessManager.h"

using namespace std;

// ---------------------------------------------------------------
// Input helper functions
// Each function keeps asking until the user enters a valid value.
// ---------------------------------------------------------------

// Removes spaces at both ends of a string
string trimText(const string& text) {
    size_t start = 0;
    while (start < text.size() && isspace(static_cast<unsigned char>(text[start]))) {
        start++;
    }
    size_t end = text.size();
    while (end > start && isspace(static_cast<unsigned char>(text[end - 1]))) {
        end--;
    }
    return text.substr(start, end - start);
}

// Shows a prompt and reads one whole line
string readLine(const string& prompt) {
    string line;
    cout << prompt;
    if (!getline(cin, line)) {          // input closed (Ctrl+Z / end of file)
        cout << "\nInput closed. Exiting program.\n";
        exit(0);
    }
    return trimText(line);
}

// Reads a whole number between minValue and maxValue
int readInt(const string& prompt, int minValue, int maxValue) {
    while (true) {
        stringstream ss(readLine(prompt));
        int value;
        char extra;
        // Valid only if: a number was read, nothing extra follows,
        // and the number is inside the allowed range.
        if (ss >> value && !(ss >> extra) && value >= minValue && value <= maxValue) {
            return value;
        }
        cout << "Invalid input. Enter a whole number from "
             << minValue << " to " << maxValue << ".\n";
    }
}

// Reads a decimal number between minValue and maxValue
double readDouble(const string& prompt, double minValue, double maxValue) {
    while (true) {
        stringstream ss(readLine(prompt));
        double value;
        char extra;
        if (ss >> value && !(ss >> extra) && value >= minValue && value <= maxValue) {
            return value;
        }
        cout << "Invalid input. Enter a number from "
             << minValue << " to " << maxValue << ".\n";
    }
}

// Checks a date written as YYYY-MM-DD
bool isValidDate(const string& date) {
    if (date.size() != 10 || date[4] != '-' || date[7] != '-') {
        return false;
    }
    for (size_t i = 0; i < date.size(); i++) {
        if (i != 4 && i != 7 && !isdigit(static_cast<unsigned char>(date[i]))) {
            return false;
        }
    }

    int year = atoi(date.substr(0, 4).c_str());
    int month = atoi(date.substr(5, 2).c_str());
    int day = atoi(date.substr(8, 2).c_str());

    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1) {
        return false;
    }

    int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    bool leapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    int maxDay = daysInMonth[month - 1];
    if (month == 2 && leapYear) {
        maxDay = 29;
    }
    return day <= maxDay;
}

string readDate() {
    while (true) {
        string date = readLine("Enter date (YYYY-MM-DD): ");
        if (isValidDate(date)) {
            return date;
        }
        cout << "Invalid date. Use the format YYYY-MM-DD, for example 2026-10-18.\n";
    }
}

string readActivity() {
    cout << "Activity type:\n";
    cout << "  1. Running\n";
    cout << "  2. Walking\n";
    cout << "  3. Cycling\n";
    int choice = readInt("Choose activity (1-3): ", 1, 3);

    if (choice == 1) return "Running";
    if (choice == 2) return "Walking";
    return "Cycling";
}

// Asks a yes/no question
bool readYesNo(const string& prompt) {
    while (true) {
        string answer = readLine(prompt);
        if (answer == "y" || answer == "Y") return true;
        if (answer == "n" || answer == "N") return false;
        cout << "Please type y or n.\n";
    }
}

// ---------------------------------------------------------------
// Menu functions (one small function for each menu option)
// ---------------------------------------------------------------

void showMenu() {
    cout << "\n=====================================\n";
    cout << "     FITNESS MANAGEMENT SYSTEM\n";
    cout << "=====================================\n";
    cout << "  1. Add Workout\n";
    cout << "  2. View All Workouts\n";
    cout << "  3. Search Workout\n";
    cout << "  4. Delete Workout\n";
    cout << "  5. Calculate Total Distance\n";
    cout << "  6. Display Fitness Summary\n";
    cout << "  7. Exit\n";
    cout << "=====================================\n";
}

void addWorkoutOption(FitnessManager& manager) {
    cout << "\n--- Add New Workout ---\n";
    string date = readDate();
    string activity = readActivity();
    double distance = readDouble("Enter distance in km (0.1 - 1000): ", 0.1, 1000);
    int duration = readInt("Enter duration in minutes (1 - 1440): ", 1, 1440);
    int calories = readInt("Enter calories burned (0 - 10000): ", 0, 10000);

    manager.addWorkout(date, activity, distance, duration, calories);
}

void searchWorkoutOption(const FitnessManager& manager) {
    cout << "\n--- Search Workout ---\n";
    int id = readInt("Enter workout ID: ", 1, 1000000);
    manager.searchWorkout(id);
}

void deleteWorkoutOption(FitnessManager& manager) {
    cout << "\n--- Delete Workout ---\n";
    int id = readInt("Enter ID of the workout to delete: ", 1, 1000000);

    // searchWorkout shows the record (or a "not found" message)
    if (!manager.searchWorkout(id)) {
        return;
    }

    if (readYesNo("Delete this workout? (y/n): ")) {
        manager.deleteWorkout(id);
        cout << "Workout " << id << " deleted.\n";
    } else {
        cout << "Delete cancelled.\n";
    }
}

void totalDistanceOption(const FitnessManager& manager) {
    cout << fixed << setprecision(2);
    cout << "\nTotal distance covered: "
         << manager.calculateTotalDistance() << " km\n";
}

// ---------------------------------------------------------------
// main
// ---------------------------------------------------------------
int main() {
    FitnessManager manager("workouts.txt");
    manager.loadFromFile();             // load saved records at start

    int choice = 0;
    do {
        showMenu();
        choice = readInt("Enter your choice (1-7): ", 1, 7);

        switch (choice) {
            case 1: addWorkoutOption(manager); break;
            case 2: manager.viewAllWorkouts(); break;
            case 3: searchWorkoutOption(manager); break;
            case 4: deleteWorkoutOption(manager); break;
            case 5: totalDistanceOption(manager); break;
            case 6: manager.displaySummary(); break;
            case 7: cout << "\nAll records are saved in workouts.txt. Goodbye!\n"; break;
        }
    } while (choice != 7);

    return 0;
}
